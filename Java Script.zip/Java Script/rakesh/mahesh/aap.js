function validatePayment() {
    const name = document.getElementById("card-name").value.trim();
    const number = document.getElementById("card-number").value.trim();
    const expiry = document.getElementById("expiry").value.trim();
    const cvv = document.getElementById("cvv").value.trim();
  
    if (!/^\d{16}$/.test(number.replace(/\s/g, ''))) {
      alert("Card number must be 16 digits.");
      return false;
    }
  
    if (!/^\d{2}\/\d{2}$/.test(expiry)) {
      alert("Expiry must be in MM/YY format.");
      return false;
    }
  
    if (!/^\d{3}$/.test(cvv)) {
      alert("CVV must be 3 digits.");
      return false;
    }
  
    alert("Payment Successful!");
    return false; // Prevent actual form submission
  }
  