const products = [
    { id: 1, name: "Red T-Shirt", price: 499, image: "https://m.media-amazon.com/images/I/41N4oL+WzGL._SY300_SX300_.jpg" },
    { id: 2, name: "Blue Jeans", price: 999, image: "https://m.media-amazon.com/images/I/31GNfa+-zgL.jpg" },
    { id: 3, name: "Sneakers", price: 1499, image: "https://m.media-amazon.com/images/I/71J+6lIFz+L._SY675_.jpg" },
    { id: 4, name: "Cap", price: 199, image: "https://m.media-amazon.com/images/I/31XSRCa4J5L._SX300_SY300_QL70_FMwebp_.jpg" }
  ];
  
  let cart = [];
  
  function renderProducts() {
    const productList = document.getElementById("product-list");
    products.forEach(product => {
      const div = document.createElement("div");
      div.className = "product";
      div.innerHTML = `
        <img src="${product.image}" alt="${product.name}">
        <h3>${product.name}</h3>
        <p>₹${product.price}</p>
       <a href="http://127.0.0.1:5500/rakesh/mahesh/index.html"> <button onclick="addToCart(${product.id})">Add to Cart</button></a>
      `;
      productList.appendChild(div);
    });
  }
  
  function addToCart(productId) {
    const product = products.find(p => p.id === productId);
    cart.push(product);
    updateCart();
  }
  
  function updateCart() {
    const cartItems = document.getElementById("cart-items");
    const totalElement = document.getElementById("total");
    cartItems.innerHTML = "";
    let total = 0;
  
    cart.forEach(item => {
      const li = document.createElement("li");
      li.textContent = `${item.name} - ₹${item.price}`;
      cartItems.appendChild(li);
      total += item.price;
    });
  
    totalElement.textContent = total;
  }
  
  renderProducts();
  

  